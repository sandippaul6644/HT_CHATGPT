# ChatGPT
Chat GPT Official API

> Video URL - https://youtu.be/7q-n424WkrE

> Step 1. Use this git - https://github.com/AtikulSoftware/ChatGPT.git

> Setp 2. Go to Chat GPT official Website and login you account
Documantation URL - https://platform.openai.com/docs/introduction
