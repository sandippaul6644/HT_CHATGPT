package com.bdtopcoder.chatgpt;

public class API {
    public static String API_URL = "https://api.openai.com/v1/completions";
    public static String API = "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";
}
